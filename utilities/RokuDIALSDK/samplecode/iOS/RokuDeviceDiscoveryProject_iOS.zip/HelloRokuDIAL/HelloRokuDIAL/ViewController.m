//
//  ViewController.m
//  HelloRokuDIAL
//
//  Copyright (c) 2013 Roku, Inc. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSLog(@"ViewController viewDidLoad");
    
	// Do any additional setup after loading the view, typically from a nib.
    self.tableView.dataSource = self;
    self.tableView.layer.borderWidth = 1.0;
    self.tableView.layer.borderColor = [UIColor grayColor].CGColor;
    
    /// set up button interface
    [self.buttonBroadcast addTarget: self action: @selector(buttonBroadcastPressed) forControlEvents:UIControlEventTouchUpInside];
    self.buttonLaunch.enabled = false;
    [self.buttonLaunch addTarget: self action: @selector(buttonLaunchPressed) forControlEvents:UIControlEventTouchUpInside];
    [self.buttonStop addTarget: self action: @selector(buttonStopPressed) forControlEvents:UIControlEventTouchUpInside];
    
    // listeners to dismiss the keyboard when finished typing
    [self.textAppName setDelegate: self];
    [self.textAppName setReturnKeyType: UIReturnKeyDone];
    [self.textAppName addTarget: self
                         action: @selector(textFieldFinished:)
               forControlEvents: UIControlEventEditingDidEndOnExit];
    
    self.DIALMgr = [[DIALManager alloc] init];
    
    // go ahead and populate the table
    [self buttonBroadcastPressed];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/// dismiss the keyboard
- (IBAction)textFieldFinished:(id)sender
{
    [self.view endEditing:YES];
}

/// apply the text to the message
- (void)message:(NSString *)msg
{
    self.text.text = [NSString stringWithFormat: @"%@\n%@", self.text.text, msg];
    [self.text scrollRangeToVisible: NSMakeRange(self.text.text.length - 1, 1)];
}


/// handler for the broadcast button, rename this to "discover"
- (void) buttonBroadcastPressed
{
    if (self.runningBroadcast == true)
        return;
    
    NSLog(@"ViewController buttonBroadcastPressed");
    [self message: @"\nBroadcast Scan ..."];
    
    self.tableData = [[NSMutableArray alloc] init];
    
    self.countDiscovered = 0;
    self.runningBroadcast = true;
    self.buttonBroadcast.enabled = false;
    
    /// call start broadcast
    [Discovery startSSDPBroadcast: [[SSDPDiscoveryDelegateListener alloc] initWithOwner: self]];
}

- (void) buttonLaunchPressed
{
    NSLog(@"ViewController buttonLaunchPressed");
    [self message:@"Launch the channel ..."];
    self.buttonBroadcast.enabled = false;
    
    NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
    int selected = indexPath.row;
    DiscoveredRokuBox *box = [self.tableData objectAtIndex: selected];
    if (box == nil)
    {
        return;
    }
    NSLog(@"DIAL URL: %@", box.dialURL);
    
    
    self.launchURL = [self.DIALMgr launchApp: box.dialURL :self.textAppName.text];
    self.buttonBroadcast.enabled = true;
}

- (void) buttonStopPressed
{
    NSLog(@"ViewController buttonStopPressed");

    [self.DIALMgr sendDelete: self.launchURL];
    
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.tableData count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    static NSString *cellIdentifier = @"DiscoveredBoxCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
    }
    
    DiscoveredRokuBox *obj = [self.tableData objectAtIndex:indexPath.row];
    [cell.textLabel setText: obj.modelName];
    [cell.detailTextLabel setText: obj.serialNumber];
    return cell;
}


@end

@implementation SSDPDiscoveryDelegateListener

- (id)initWithOwner:(ViewController *)owner
{
    self = [super init];
    if (self != nil) {
        self.owner = owner;
    }
    return self;
}

- (void)onFound:(DiscoveredRokuBox *)box
{
    NSLog(@"SSDPDiscoveryDelegateListener onDevice url: %@", box.ip);
    [self.owner.tableData addObject: box];
    [self.owner message: [NSString stringWithFormat:@"Found IP: %@", box.ip]];

    self.owner.countDiscovered++;
    [self.owner.DIALMgr fetchDetails: box];
}

- (void)onFinished:(int)count
{
    [self.owner.tableView reloadData];
    NSLog(@"SSDPDiscoveryDelegateListener onFinished count: %i found", count);
    [self.owner message:[NSString stringWithFormat:@"Finished Broadcast: %i discovered",self.owner.countDiscovered]];
    
    self.owner.runningBroadcast = false;
    self.owner.buttonBroadcast.enabled = true;
    self.owner.buttonLaunch.enabled = true;
}

@end
