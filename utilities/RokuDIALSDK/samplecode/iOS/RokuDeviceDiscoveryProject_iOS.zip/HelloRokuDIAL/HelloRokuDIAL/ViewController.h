//
//  ViewController.h
//  HelloRokuDIAL
//
//  Copyright (c) 2013 Roku, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Discovery.h"
#import "DIALManager.h"
#import "QuartzCore/QuartzCore.h"

// ViewController interface
@interface ViewController : UIViewController <UITableViewDataSource, UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextView *text;
@property (weak, nonatomic) IBOutlet UIButton *buttonLaunch;
@property (weak, nonatomic) IBOutlet UIButton *buttonBroadcast;
@property (weak, nonatomic) IBOutlet UIButton *buttonStop;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) NSMutableArray *tableData;
@property (weak, nonatomic) IBOutlet UITextField *textAppName;

@property (nonatomic) BOOL runningBroadcast;
@property (strong, nonatomic) NSString *launchURL;
@property (strong, nonatomic) DIALManager *DIALMgr;
@property (nonatomic) int countDiscovered;

@end

// SSDPDiscoveryDelegateListener interface
@interface SSDPDiscoveryDelegateListener : NSObject<DiscoveryEventsDelegate>

@property ViewController *owner;
- (id)initWithOwner:(ViewController *) owner;

@end