//
//  AppDelegate.h
//  HelloRokuDIAL
//
//  Copyright (c) 2013 Roku, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
