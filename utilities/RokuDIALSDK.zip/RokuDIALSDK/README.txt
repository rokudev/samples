This package contains the following items

* RokuDIALProgramming.pdf  Documentation of how to program DIAL for Roku second screen applications.
* 2DVideo.zip Sample BrightScript channel
* RokuDeviceDiscoveryProject_Android.zip Sample Android application
* RokuDeviceDiscoveryProject_iOS.zip Sample iOS Application
