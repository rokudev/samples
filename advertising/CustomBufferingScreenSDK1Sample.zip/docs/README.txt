Roku Advertising Framework.  
This is a universal video ad solution integrated directly into the core Roku SDK.  
This framework natively integrates baseline & advanced advertising capabilities.
Here are few examples for integrating RAF to channel with support of Nielsen Digital Ad Ratings
in a simple channel based on list and video screen.

I. Description

	1. Customized Default Ad Buffering Screen
	
		In this implementation was used customized default Ad buffering screen. RAF is configured (initialized) in a standard way. 
	Then create a bufferScreenContent object with optional fields for buffer screen customization and populate it to RAF using 
	SetAdBufferScreenContent function. Next turn on Nielsen and configure it with documented parameters genre, program id and content. 
	Then configure ad url with some passed parameters via Macros and set Ad URL with setAdUrl() method. After that get ads with getAds() 
	(in example used VAST format) and render them with showAds().
	
	2. Custom Ad Buffering Screen
	
		In this implementation was used fully customized Ad buffering screen instead of default one. As always configure (initialize) RAF first. 
	Then create a custom objects to represent layers of roImageCanvas. Next set the objects to RAF with specified zOrder 
	using setAdBufferScreenLayer function. After that set callback function for handling ad buffering events 
	by setAdBufferRenderCallback function. Next turn on Nielsen and configure it with documented parameters genre, program id 
	and content. Then configure ad url with some passed parameters via Macros and set Ad URL with setAdUrl() method. 
	After that get ads with getAds() (in example used VAST format) and render them with showAds().