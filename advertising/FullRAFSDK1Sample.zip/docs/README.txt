Roku Advertising Framework.  
This is a universal video ad solution integrated directly into the core Roku SDK.  
This framework natively integrates baseline & advanced advertising capabilities.
Here are few examples for integrating RAF to channel with support of Nielsen Digital Ad Ratings
in a simple channel based on list and video screen.

I. Description
	
	1. Full RAF integration
	
		At first RAF is configured (initialized) in a standard way. Turn on Nielsen and configure it with documented parameters genre, 
	program id and content. Then configure ad url with some passed parameters via Macros and set Ad URL with setAdUrl() method. After that
	get ads with getAds() (in example used VAST format) and render them with showAds().

	2. Custom Ad Parsing
    
       In this implementation ads are imported from non-standard feed (neither VMAP, VAST or SMartXML).
    RAF is configured in a standard way, with backfill ads disabled and extra debug output enabled. Ads are parsed
    from local JSON file, then formatted as ad pods array and imported into RAF using importAds() method.
       After that check for particular ads to play by passing videoScreen events to RAF getAds() method 
    inside event-loop. If any ads were returned from getAds(), they are rendered using RAF showAds() method.

	3. Customized Default Ad Buffering Screen
	
		In this implementation was used customized default Ad buffering screen. RAF is configured (initialized) in a standard way. 
	Then create a bufferScreenContent object with optional fields for buffer screen customization and populate it to RAF using 
	SetAdBufferScreenContent function. Next turn on Nielsen and configure it with documented parameters genre, program id and content. 
	Then configure ad url with some passed parameters via Macros and set Ad URL with setAdUrl() method. After that get ads with getAds() 
	(in example used VAST format) and render them with showAds().
	
	4. Custom Ad Buffering Screen
	
		In this implementation was used fully customized Ad buffering screen instead of default one. As always configure (initialize) RAF first. 
	Then create a custom objects to represent layers of roImageCanvas. Next set the objects to RAF with specified zOrder 
	using setAdBufferScreenLayer function. After that set callback function for handling ad buffering events 
	by setAdBufferRenderCallback function. Next turn on Nielsen and configure it with documented parameters genre, program id 
	and content. Then configure ad url with some passed parameters via Macros and set Ad URL with setAdUrl() method. 
	After that get ads with getAds() (in example used VAST format) and render them with showAds().
	
	5. Test Stitched Ads: Mixed
	
		At first configure (initialize) RAF. Ads are parsed from local JSON file, then formatted as ad pods array (normally, ads will be populated 
	from publisher's ad URL using setAdUrl and getAds function). Then initialize this server-stitched ads using stitchedAdsInit function.
		After initialization video event loop was started. At first check if stitched ad was rendered. For this use a 
	stitchedAdHandledEvent function passing it video player message from message port and video player context. If there is no current ad 
	or ad did not handle event, the video player message fall through to default event handling.