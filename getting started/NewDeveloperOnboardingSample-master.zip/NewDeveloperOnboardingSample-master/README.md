# NewDeveloperOnboardingSample
A very basic channel intended to help bring new devs up to speed with Scenegraph and Brightscript
